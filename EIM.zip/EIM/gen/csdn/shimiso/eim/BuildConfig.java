/** Automatically generated file. DO NOT MODIFY */
package csdn.shimiso.eim;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}